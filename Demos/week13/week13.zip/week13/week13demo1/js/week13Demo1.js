

//This is the javascript file for week13demo1
// It demonstrates the use of the first(), last() and next() methods.

//The javascript $ loading function(representing document.ready)

$(() => {

    /*
    $("#button1").on("click", () => {
        $("p").first().css("color", "blue");
    });


    $("#button2").on("click", () => {
        $("p").last().css("color", "red");
    });

    $("#button3").on("click", () => {
        let elem = $("p").first().next();
        while (elem.attr("id") != $("p").last().attr("id")) {
            elem.css("color", "green");
            elem = elem.next();

        }
    });
*/

});
