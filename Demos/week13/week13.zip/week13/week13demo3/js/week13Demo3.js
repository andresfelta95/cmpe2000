//javascript file for wek3demo3


$(() => {

    /*
    $("#button1").on("click", () => {

        $("#section1").addClass("emphasized");

    });

    $("#button2").on("click", () => {

        $("#section1").removeClass("emphasized");

    });
*/
})