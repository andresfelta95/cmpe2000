
//This is the javascript file for week13-demo2
//It illustrates the use of the parent() method

$(() => {
    /*
    $("[name=commute]").each((index, item) => {

        $(item).on("click", () => {

            $("[name=commute]").each((index1, item1) => {

                if (item1.checked)
                    $(item1).parent().css("background-color", "yellow");
                else
                    $(item1).parent().css("background-color", "transparent");

            })

        })
    })

*/

});


