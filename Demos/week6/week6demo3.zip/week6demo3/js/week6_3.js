




function setTextAny() {
    var str = prompt("give the paragraph number", "3");
    if (isNaN(str)) {
        alert("The value input is not valid");
    }
    else {
        var num = parseInt(str);
        var elem = document.querySelector("#p" + num);
        var str1 = prompt("give the string you want to display", "None");
        elem.innerHTML = str1;
    }

}