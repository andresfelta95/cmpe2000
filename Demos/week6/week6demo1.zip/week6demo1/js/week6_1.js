

function inputName() {
    var myname;
    myname = window.prompt('Input Your Name', "No Name");
    alert("Name input was;  " + myname);
}
