

function modifyText() {
    var str, previousprompt;
    console.log("this=");
    console.log(this);
    previousPrompt = this.innerHTML;
    str = prompt("Give the new text", previousPrompt);
    this.innerHTML = str;

}
