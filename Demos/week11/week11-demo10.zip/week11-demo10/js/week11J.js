//Javascript for week11-demo10
