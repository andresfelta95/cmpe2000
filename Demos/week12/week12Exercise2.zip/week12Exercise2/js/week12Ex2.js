/*Anonymous function loaded when the html document is ready. 
   Note that this is similar to the anonymous function we 
   have for the window.onload event.
   We can also use $(document.ready(){   })
               */
$(function () {

    //registering the anonymous function (or arrow function)
    //for the click event of the button
    $("#button1").on("click", () => {
        //Write your code here for this event handler

    });

});


/*Callback function for success
  We are having a simple function here that simply displays
  the obtained json object to the console
  Remember that for the callback function of the the success property
  the first parameter always represents the returned data.
  The second parameter represents the status of the result 
   */
function processSuccess(result, resultStatus) {



}

/*callback function for Error
It's a simplified version that simply displays a 
message on the console.
*/
function processError() {
    console.log("An error has occured");
}