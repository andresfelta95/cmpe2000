<?php
echo "Hi- It's a nice day today"."<br>";
echo "name=".$_GET['getName']."<br>";
echo "score=".$_GET['getScore'];
?>                 