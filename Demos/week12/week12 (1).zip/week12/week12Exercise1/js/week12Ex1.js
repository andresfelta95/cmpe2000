//This is the first javascript file for Exercise 12.1
// We here pass a literal object as parameter to the
//ajax() call

